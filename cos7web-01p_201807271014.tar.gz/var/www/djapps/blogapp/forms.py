from django import forms

class NameForm(forms.Form):
    blog_title = forms.CharField(label='Blog Title', max_length=100)
    blog_author = forms.CharField(label='Your Name', max_length=100)
    blog_content = forms.CharField(widget=forms.Textarea)

class ContactForm(forms.Form):
    name = forms.CharField()
    message = forms.CharField(widget=forms.Textarea)

    def send_email(self):
        # send email using the self.cleaned_data dictionary
        pass
