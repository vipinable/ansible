# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.test import TestCase

# Create your tests here.
from blogapp.models import Blog
b = Blog(name='Beatles Blog', tagline='All the latest Beatles news.')
b.save()
