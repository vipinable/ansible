# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.views.generic.edit import FormView
from .models import Blog
from .models import Author
from .models import Entry


def calendar():
   import datetime, calendar
   c = calendar.TextCalendar(calendar.SUNDAY)
   cal = c.formatmonth(int(datetime.date.today().isoformat().split('-')[0]), int(datetime.date.today().isoformat().split('-')[1]))
   calendar = ''
   today = datetime.date.today().ctime().split()[2]
   for week in cal.strip().split('\n')[2:]:
       calendar = calendar + '<tr>\n'
       span = 7 - len(week.split())
       if span > 0 and today < 15:
          calendar = calendar + '  <td colspan="'+str(span)+'" class="pad"><span>&nbsp;</span></td>\n'
       for date in week.split():
          if date == today:
             calendar = calendar + '  <td class="today"><a href="#">'+str(date)+'</a></td>\n'
          else:
             calendar = calendar + '  <td><span>'+str(date)+'</span></td>\n'
       if span > 0 and today >= 15:
          calendar = calendar + '  <td colspan="'+str(span)+'" class="pad"><span>&nbsp;</span></td>\n'
       calendar = calendar + '</tr>\n'
   return calendar

def post_list(request):
    c = calendar.TextCalendar(calendar.SUNDAY)
    calendar = c.formatmonth(int(datetime.date.today().isoformat().split('-')[0]), int(datetime.date.today().isoformat().split('-')[1]))
    print calendar
    record = Entry.objects.order_by('blog')
    record['calendar'] = calendar
    return render(request, 'blogapp/post_list.html', {'posts': record, 'calendar': calendar})

def index(request):
   record = Entry.objects.order_by('blog')
   return render(request, 'blogapp/index.html', {'posts': record, 'calendar': calendar()})
   #template = loader.get_template('blogapp/index.html')
   #return HttpResponse(template.render(request))
   #context = {
   #     'posts': record,
   # }
   #return HttpResponse(template.render(context, request))

def archives(request):
   record = Entry.objects.order_by('blog')
   return render(request, 'blogapp/archives.html', {'posts': record, 'calendar': calendar()})


def projects(request):
   record = Entry.objects.order_by('blog')
   return render(request, 'blogapp/projects.html', {'posts': record, 'calendar': calendar()})

def astronomy(request):
   record = Entry.objects.order_by('blog')
   return render(request, 'blogapp/astronomy.html', {'posts': record, 'calendar': calendar()})

def technology(request):
   record = Entry.objects.order_by('blog')
   return render(request, 'blogapp/technology.html', {'posts': record, 'calendar': calendar()})
