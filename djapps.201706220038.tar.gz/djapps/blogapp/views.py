# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader


def index(request):
   latest_question_list = 'Whats up'
   template = loader.get_template('blogapp/index.html')
   return HttpResponse(template.render(request))
   context = {
        'latest_question_list': latest_question_list,
    }
   return HttpResponse(template.render(context, request))
#def index(request):
#    return HttpResponse("<h4>This is a Test page</h4>")
